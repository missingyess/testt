interface Tribe {
    name: string;
    ownerSID: number;
    membersSIDs: number[];
}

export { Tribe };