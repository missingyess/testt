export enum WeaponVariant {
    Normal = 0,
    Gold = 1,
    Diamond = 2,
    Ruby = 3
}